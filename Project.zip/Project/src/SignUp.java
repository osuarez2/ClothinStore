import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;

import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JButton;

public class SignUp {

	private JFrame frame;
	private JTextField txtUserid;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtType;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp window = new SignUp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SignUp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sign Up");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblNewLabel.setBounds(148, 10, 139, 43);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User Id");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(67, 66, 60, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtUserid = new JTextField();
		txtUserid.setBounds(25, 96, 139, 22);
		frame.getContentPane().add(txtUserid);
		txtUserid.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(52, 128, 86, 22);
		frame.getContentPane().add(lblNewLabel_2);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(25, 155, 139, 22);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(283, 133, 86, 13);
		frame.getContentPane().add(lblNewLabel_3);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(255, 155, 139, 22);
		frame.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Who are you? (Type)");
		lblNewLabel_4.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(245, 69, 170, 22);
		frame.getContentPane().add(lblNewLabel_4);
		
		txtType = new JTextField();
		txtType.setBounds(255, 96, 139, 21);
		frame.getContentPane().add(txtType);
		txtType.setColumns(10);
		
		JButton btnNewButton = new JButton("SignUp");
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnNewButton.setBounds(157, 201, 117, 21);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Put code here that you want to run when this button is clicked
				addCustomUser(); // Adds the new patient to the database when the button is clicked
			}
		});
	}
		public void addCustomUser() {
			try {
				String query = "INSERT INTO users VALUES (?, ?, ?, ?)";
				PreparedStatement stm = Database.connection.prepareStatement(query);
				
				stm.setInt(1, Integer.parseInt(txtUserid.getText())); 
				stm.setString(2, txtUsername.getText());
				stm.setString(3, txtPassword.getText()); 
				stm.setString(4, txtType.getText());
				stm.executeUpdate();
				// The line below is ran if the query executes successfully. It shows a JOptionPane (an alert) telling the user that the patient has been added to the database.
				JOptionPane.showMessageDialog(null, "The new Account was added to the database!", "Account Made!", JOptionPane.DEFAULT_OPTION);
			} catch (Exception e) {
				System.out.println(e);
			}
		
	}
}
